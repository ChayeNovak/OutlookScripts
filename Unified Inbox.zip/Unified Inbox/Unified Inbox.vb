Sub UnifiedInbox()
Dim myOutApp As New Outlook.Application
txtSearch = "folder:Inbox"
myOutApp.ActiveExplorer.Search txtSearch, olSearchScopeAllFolders
Set myOlApp = Nothing
End Sub