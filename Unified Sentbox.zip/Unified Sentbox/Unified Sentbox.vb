Sub UnifiedSentbox()
Dim myOutApp As New Outlook.Application
txtSearch = "folder: (Sent Mail)"
myOlApp.ActiveExplorer.Search txtSearch, olSearchScopeAllFolders
Set myOutApp = Nothing
End Sub
